let dolar = prompt("Digite seu valor em dolar: ")

dolar = parseFloat(dolar)

conversor = dolar*5.80;

alert("Seus dolares convertidos para reais: "+conversor)