let valor = prompt("Digite seu valor:  ")

valor = parseFloat(valor)

reajuste2 = ((valor*0.3333)+valor)

alert("O valor do seu produto após o reajuste 33,33% é: "+reajuste2)