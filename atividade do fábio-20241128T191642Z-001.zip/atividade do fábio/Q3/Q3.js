let reais = prompt("Digite seu valor em reais: ")

reais = parseFloat(reais)

conversor = reais/5.8

alert("Seus reais convertidos para dolares são: "+conversor)