let i = prompt("Digite seu número: ")

i = parseFloat(i)

if(i%2==0){
    alert("Seu número é par")
}else{
    alert("Seu número é ímpar")
}
