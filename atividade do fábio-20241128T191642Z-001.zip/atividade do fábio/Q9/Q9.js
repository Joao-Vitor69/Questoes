let i = prompt("Digite seu número: ")

i = parseFloat(i)

if(i>0){
    alert("Seu número é positivo")
}
else{
    alert("Seu número é negativo")
}