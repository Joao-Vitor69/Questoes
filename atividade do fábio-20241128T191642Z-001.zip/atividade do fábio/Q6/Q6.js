fah = prompt("Digite sua temperatura em Fahrenheit: ")

fah = parseFloat(fah)

conversor3 = ((fah-32)/9)*5

alert("Sua temperatura em celsius é de: "+conversor3)