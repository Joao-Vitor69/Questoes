cel = prompt("Digite sua temperatura em celsius: ")

cel = parseFloat(cel)

conversor4 = ((cel*(9/5))+32)

alert("Seu valor em graus fahrenheit é: "+conversor4)