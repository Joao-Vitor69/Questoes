let i = prompt("Digite seu número: ")

i = parseFloat(i)

if(i>0){
    alert("Você digitou um numero positivo")
}else if(i==0){
    alert("Você digitou zero")
}
else{
    alert("Você digitou um numero negativo")
}