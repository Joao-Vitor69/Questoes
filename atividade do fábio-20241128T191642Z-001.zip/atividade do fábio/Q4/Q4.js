let saldo = prompt("Digite seu saldo: ")

saldo = parseFloat(saldo)

reajuste = (saldo * 0.01)+saldo

alert("Seu saldo com reajuste de 1% fica: "+reajuste)